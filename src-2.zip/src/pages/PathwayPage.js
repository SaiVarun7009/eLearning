import React from "react";
import PathwayBanner from '../components/Banner/PathwayBanner'
import Description from '../components/Description/Description'
// import PathwayCourses from '../components/PathwayCourses/PathwayCourse'
// import SlickCourse from '../components/PathwayCourses/SlickCourse'
import SlickCourse2 from '../components/PathwayCourses/SlickCourse2'
import Reference from '../components/References/Reference'




const PathwayPage = () => {
  return (
    <div> dhhsrfh
        <PathwayBanner/>
        {/* <Description/> */}
        <br/>
        {/* <PathwayCourses/> */}
        {/* <SlickCourse /> */}
        <br/><br/>
        <SlickCourse2 />
        <Reference/>
    </div>
  )
}

export default PathwayPage