import React from 'react'
import CourseBanner from '../components/Banner/CourseBanner'
// import Curriculum from '../components/courseCurriculum/Curriculum'
import CourseCurriculum from '../components/courseCurriculum/courseCurriculum'
import Description from '../components/Description/Description'


const CoursePage = () => {
  return (

    <div>CoursePage
      <CourseBanner />

      <Description/>
      <CourseCurriculum/>
    </div>
    

  )
}

export default CoursePage