import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import PathwayBanner from '../components/Banner/PathwayBanner'
import Description from '../components/Description/Description'
import SlickCourse2 from '../components/PathwayCourses/SlickCourse2'
import Reference from '../components/References/Reference'
// import Course from '../components/Course/Course'
import '../components/PathwayCourses/SlickCourse.css'
import { useNavigate } from 'react-router-dom'



const DummyPathway = () => {

    const { pathwayId } = useParams();
  const navigate = useNavigate()
    const [pathway, setPathway] = useState(null);
    const [courses, setCourses] = useState([]);

    useEffect(() => {
      const fetchPathway = async () => {
        try {
          const response = await axios.get(`http://localhost:5000/api/pathways/${pathwayId}`);
          setPathway(response.data);

          const coursesResponse = await axios.get(`http://localhost:5000/api/pathways/${pathway.title}/courses`);
          setCourses(coursesResponse.data);
        } catch (error) {
          console.log("Error is ");
          console.log(error);
        }
      };
      fetchPathway();
    }, [pathwayId]);

    if (!pathway) {
      return <div>Loading...</div>;
    }

  return (
    <div>
        <PathwayBanner title={pathway.title} description={pathway.miniDescription}/>
        <Description descData={{description: pathway.description, learningObjectives: pathway.pathwayOutcomes}}/>
        <SlickCourse2 />
        <div>
          {courses.map((course) => (
           
            // <Course key={course._id} title={course.title} description={course.description} />
            <div key={course._id}>
                 <h1>{course.title} </h1>
                <div className="singleCourse">
                    <div className='imageDiv'>
                        <img src={course.image} alt ="{courseTitle}"/>
                    </div>
                    <div className="courseInfo">
                        <p style={{height: "3rem", font:"Clinton"}} >{course.instructor}</p>
                        <h4 style={{height: "4rem", font:"Clinton", marginBottom:"15px"}}>{course.title}</h4>
                        <div className="duration"  style={{marginBottom:"15px"}}>{course.lecturesTotalTime}</div>
                        <div className='price'style={{marginBottom:"15px"}}>
                            <h3>free</h3>
                        </div>                            
                        <div >
                            <button className="butn" onClick={() => navigate(`/courses/${course._id}`)}>
                                Start Learning
                            </button>
                        </div>
                        <h4>{course.title}</h4>
                    </div>
                </div>
            </div>
          ))}
        </div>
        <Reference/>
    </div>
  )
}

export default DummyPathway



// import React, { useState, useEffect } from "react";
// import { useParams } from "react-router-dom";
// import axios from "axios";
// import PathwayBanner from '../components/Banner/PathwayBanner'
// import Description from '../components/Description/Description'
// import SlickCourse2 from '../components/PathwayCourses/SlickCourse2'
// import Reference from '../components/References/Reference'


// const DummyPathway = () => {
//     const { pathwayId } = useParams();

//     const [pathway, setPathway] = useState(null);
  
//     useEffect(() => {
//       const fetchPathway = async () => {
//       //   console.log("H1", courseId, course);
//         try {
//           // const response = await axios.get(
//           //   `http://localhost:5000/api/courses/643807996a6aca591bec35ac`
//           // );
//           // console.log("H2");
//           const response = await axios.get(`http://localhost:5000/api/pathways/${pathwayId}`);
//         //   console.log("course data:", response.data);
//           setPathway(response.data);
//         } catch (error) {
//           console.log("Error is ");
//           console.log(error);
//         }
//       };
//       fetchPathway();
//     }, [pathwayId]);
  
//     if (!pathway) {
//       return <div>Loading...</div>;
//     }

//   return (
//     <div>DummyPathway
//         <PathwayBanner title = {pathway.title} description = {pathway.miniDescription}/>
//         {/* <PathwayBanner/> */}
//         <Description descData = {{description: pathway.description, learningObjectives: pathway.pathwayOutcomes}}/>
//         <SlickCourse2 />
//         <Reference/>
//     </div>
//   )
// }

// export default DummyPathway