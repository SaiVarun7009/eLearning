const Data = [
    {
      id:1,
      section: "Section 1: Orientation for the course",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },
    {
      id:2,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },
    {
      id:3,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },
    {
      id:4,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },{
      id:5,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },
    {
      id:6,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },
    {
      id:7,
      section: "Section 1: Orientation for the course",
      topics: [
        "1.1 blockchain",
        "1.2 How does it work",
        "1.3 types",
        "1.4 jhfeh"
      ]
    },
    {
      id:8,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },
    {
      id:9,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },
    {
      id:10,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },{
      id:11,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    },
    {
      id:12,
      section: "How does Block chain work",
      topics: [
        "blockchain",
        "How does it work",
        "types",
        "jhfeh"
      ]
    }
  ] 

  export default Data