import React from 'react'

const Exam = () => {
  return (
    <div>Exam</div>
  )
}

export default Exam