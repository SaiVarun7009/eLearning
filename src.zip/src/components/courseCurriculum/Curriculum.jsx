import React, { useState, useRef } from 'react';
import './courseCurriculum.css';
import Data from './syllabus';
import { Icon } from '@iconify/react';